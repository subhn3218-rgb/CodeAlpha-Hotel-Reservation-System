package com.hotel.model;

/**
 * Enum representing the different room categories offered by the hotel.
 */
public enum RoomCategory {
    STANDARD("Standard", 5000.0),
    DELUXE("Deluxe", 9000.0),
    SUITE("Suite", 15000.0);

    private final String displayName;
    private final double basePrice;

    RoomCategory(String displayName, double basePrice) {
        this.displayName = displayName;
        this.basePrice = basePrice;
    }

    public String getDisplayName() {
        return displayName;
    }

    public double getBasePrice() {
        return basePrice;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
