package com.hotel.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * ╔══════════════════════════════════════════════════╗
 *  Reservation — Core Data Model
 *  Hotel Reservation System
 * ╚══════════════════════════════════════════════════╝
 *
 * Represents a single booking made by a customer.
 * Stores all booking details: room, dates, payment, status.
 *
 * Status Flow:
 *   CONFIRMED  →  CANCELLED  (via CancellationPanel)
 *   CONFIRMED  →  REFUNDED   (via RefundPanel — 50% returned)
 */
public class Reservation implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd MMM yyyy");

    // ==================== STATUS ENUM ====================
    public enum Status {
        CONFIRMED,
        CANCELLED,
        REFUNDED;

        /** Returns a display-friendly capitalized label. */
        public String getDisplayName() {
            String name = this.name();
            return name.charAt(0) + name.substring(1).toLowerCase();
        }
    }

    // ==================== FIELDS ====================
    private final String    reservationId;
    private final String    username;
    private final String    roomNumber;
    private final LocalDate checkIn;
    private final LocalDate checkOut;
    private       double    totalAmount;
    private       Status    status;
    private       boolean   paid;
    private final String    cardLast4;

    // ==================== CONSTRUCTOR ====================
    public Reservation(String reservationId,
                        String username,
                        String roomNumber,
                        LocalDate checkIn,
                        LocalDate checkOut,
                        double totalAmount,
                        Status status,
                        boolean paid,
                        String cardLast4) {
        this.reservationId = reservationId;
        this.username      = username;
        this.roomNumber    = roomNumber;
        this.checkIn       = checkIn;
        this.checkOut      = checkOut;
        this.totalAmount   = totalAmount;
        this.status        = status;
        this.paid          = paid;
        this.cardLast4     = cardLast4;
    }

    // ==================== GETTERS ====================
    public String    getReservationId() { return reservationId; }
    public String    getUsername()      { return username;      }
    public String    getRoomNumber()    { return roomNumber;    }
    public LocalDate getCheckIn()       { return checkIn;       }
    public LocalDate getCheckOut()      { return checkOut;      }
    public double    getTotalAmount()   { return totalAmount;   }
    public Status    getStatus()        { return status;        }
    public boolean   isPaid()           { return paid;          }
    public String    getCardLast4()     { return cardLast4;     }

    // ==================== SETTERS (mutable fields only) ====================

    /** Update reservation status (CONFIRMED → CANCELLED / REFUNDED). */
    public void setStatus(Status status) {
        this.status = status;
    }

    /** Update total amount (used by RefundPanel to apply 50% deduction). */
    public void setTotalAmount(double amount) {
        if (amount < 0) throw new IllegalArgumentException("Amount cannot be negative.");
        this.totalAmount = amount;
    }

    /** Mark reservation as paid/unpaid. */
    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    // ==================== COMPUTED / UTILITY ====================

    /** Number of nights between check-in and check-out. */
    public long getNights() {
        return ChronoUnit.DAYS.between(checkIn, checkOut);
    }

    /** 50% refund amount (used in RefundPanel popup display). */
    public double getRefundAmount() {
        return totalAmount * 0.5;
    }

    /** Returns true if the reservation can still be cancelled or refunded. */
    public boolean isActionable() {
        return status == Status.CONFIRMED;
    }

    /**
     * Human-readable summary — useful for logs and confirmation dialogs.
     * Example:
     *   RES1720000000000 | Room 101 | Ali Hassan
     *   Check-in: 05 Jul 2026 → Check-out: 08 Jul 2026 (3 nights)
     *   Total: Rs.15000.0 | Status: Confirmed | Card: ****5678
     */
    public String getSummary() {
        return String.format(
                "%s  |  Room %s  |  %s%n" +
                "Check-in: %s  →  Check-out: %s  (%d night%s)%n" +
                "Total: Rs.%.2f  |  Status: %s  |  Card: ****%s",
                reservationId, roomNumber, username,
                checkIn.format(DATE_FMT), checkOut.format(DATE_FMT),
                getNights(), getNights() == 1 ? "" : "s",
                totalAmount, status.getDisplayName(), cardLast4
        );
    }

    // ==================== SERIALIZATION (File Storage) ====================

    /**
     * Converts reservation to pipe-delimited CSV line for file storage.
     * Format: id|username|room|checkIn|checkOut|amount|status|paid|card
     */
    public String toCsv() {
        return String.join("|",
                reservationId,
                username,
                roomNumber,
                checkIn.toString(),
                checkOut.toString(),
                String.valueOf(totalAmount),
                status.name(),
                String.valueOf(paid),
                cardLast4
        );
    }

    /**
     * Reconstructs a Reservation from a pipe-delimited CSV line.
     * Inverse of toCsv().
     */
    public static Reservation fromCsv(String line) {
        if (line == null || line.isBlank()) {
            throw new IllegalArgumentException("Cannot parse empty CSV line.");
        }
        String[] p = line.split("\\|", -1);
        if (p.length < 9) {
            throw new IllegalArgumentException("Invalid CSV format: " + line);
        }
        return new Reservation(
                p[0],
                p[1],
                p[2],
                LocalDate.parse(p[3]),
                LocalDate.parse(p[4]),
                Double.parseDouble(p[5]),
                Status.valueOf(p[6]),
                Boolean.parseBoolean(p[7]),
                p[8]
        );
    }

    // ==================== toString ====================

    @Override
    public String toString() {
        return "Reservation{" +
                "id='"    + reservationId + '\'' +
                ", room=" + roomNumber    +
                ", user=" + username      +
                ", from=" + checkIn       +
                ", to="   + checkOut      +
                ", amt=Rs."+ totalAmount  +
                ", status="+ status       +
                ", paid="  + paid         +
                '}';
    }
}