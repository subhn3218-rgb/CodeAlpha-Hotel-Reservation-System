package com.hotel.model;

import java.io.Serializable;

/**
 * Represents a single hotel room.
 */
public class Room implements Serializable {
    private static final long serialVersionUID = 2L;

    private String roomNumber;
    private RoomCategory category;
    private double pricePerNight;
    private boolean available;
    private String imagePath;
    private String description;
    private int maxGuests;          // ← NEW FIELD

    // New full constructor (with maxGuests)
    public Room(String roomNumber, RoomCategory category, double pricePerNight,
                boolean available, String imagePath, String description, int maxGuests) {
        this.roomNumber    = roomNumber;
        this.category      = category;
        this.pricePerNight = pricePerNight;
        this.available     = available;
        this.imagePath     = imagePath;
        this.description   = description;
        this.maxGuests     = maxGuests;
    }

    // Old constructor (backward compatible — defaults maxGuests by category)
    public Room(String roomNumber, RoomCategory category, double pricePerNight,
                boolean available, String imagePath, String description) {
        this(roomNumber, category, pricePerNight, available, imagePath, description,
             defaultMaxGuests(category));
    }

    /** Returns a sensible default guest limit based on room category. */
    private static int defaultMaxGuests(RoomCategory cat) {
        switch (cat) {
            case STANDARD: return 2;
            case DELUXE:   return 3;
            case SUITE:    return 4;
            default:       return 2;
        }
    }

    // -------- Getters / Setters --------

    public String getRoomNumber()      { return roomNumber; }
    public RoomCategory getCategory()  { return category; }
    public double getPricePerNight()   { return pricePerNight; }
    public boolean isAvailable()       { return available; }
    public void setAvailable(boolean available) { this.available = available; }
    public String getImagePath()       { return imagePath; }
    public String getDescription()     { return description; }
    public int getMaxGuests()          { return maxGuests; }           // ← NEW
    public void setMaxGuests(int max)  { this.maxGuests = max; }      // ← NEW

    // -------- CSV Serialization --------

    /** Serializes this room as a single CSV line for file storage. */
    public String toCsv() {
        return roomNumber + "|" + category.name() + "|" + pricePerNight + "|" +
                available + "|" + imagePath + "|" + description + "|" + maxGuests;
    }

    public static Room fromCsv(String line) {
        String[] p = line.split("\\|", -1);
        // Support old 6-field format and new 7-field format
        int guests = (p.length >= 7)
                ? Integer.parseInt(p[6])
                : defaultMaxGuests(RoomCategory.valueOf(p[1]));
        return new Room(p[0], RoomCategory.valueOf(p[1]), Double.parseDouble(p[2]),
                Boolean.parseBoolean(p[3]), p[4], p[5], guests);
    }

    @Override
    public String toString() {
        return roomNumber + " - " + category.getDisplayName()
                + " (Rs." + pricePerNight + "/night, Max " + maxGuests + " guests)";
    }

    public int getNumber() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}