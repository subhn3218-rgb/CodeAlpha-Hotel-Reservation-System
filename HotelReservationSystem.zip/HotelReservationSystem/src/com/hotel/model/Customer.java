package com.hotel.model;

import java.io.Serializable;

/**
 * Represents a registered user/customer of the hotel system.
 */
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private String fullName;
    private String email;
    private String phone;

    public Customer(String username, String password, String fullName, String email, String phone) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }

    public String toCsv() {
        return username + "|" + password + "|" + fullName + "|" + email + "|" + phone;
    }

    public static Customer fromCsv(String line) {
        String[] p = line.split("\\|", -1);
        return new Customer(p[0], p[1], p[2], p[3], p[4]);
    }
}
