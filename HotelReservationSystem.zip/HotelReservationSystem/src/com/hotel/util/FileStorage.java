package com.hotel.util;

import com.hotel.model.*;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Handles all file I/O for the system. Data is stored as simple pipe-delimited
 * text files inside the /data folder, acting as a lightweight flat-file database.
 */
public class FileStorage {

    private static final String DATA_DIR = "data";
    private static final String ROOMS_FILE = DATA_DIR + File.separator + "rooms.txt";
    private static final String CUSTOMERS_FILE = DATA_DIR + File.separator + "customers.txt";
    private static final String RESERVATIONS_FILE = DATA_DIR + File.separator + "reservations.txt";

    public FileStorage() {
        try {
            Files.createDirectories(Paths.get(DATA_DIR));
            if (!Files.exists(Paths.get(ROOMS_FILE))) {
                seedRooms();
            }
            if (!Files.exists(Paths.get(CUSTOMERS_FILE))) {
                Files.createFile(Paths.get(CUSTOMERS_FILE));
            }
            if (!Files.exists(Paths.get(RESERVATIONS_FILE))) {
                Files.createFile(Paths.get(RESERVATIONS_FILE));
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize data files: " + e.getMessage(), e);
        }
    }

    /** Creates a default set of rooms the first time the app runs. */
    private void seedRooms() throws IOException {
        List<Room> seed = new ArrayList<>();
        String[][] data = {
                {"101", "STANDARD", "images/standard.png", "Cozy standard room with a queen bed."},
                {"102", "STANDARD", "images/standard.png", "Standard room with city view."},
                {"103", "STANDARD", "images/standard.png", "Standard room near the lobby."},
                {"201", "DELUXE", "images/deluxe.png", "Deluxe room with king bed and balcony."},
                {"202", "DELUXE", "images/deluxe.png", "Deluxe room with garden view."},
                {"301", "SUITE", "images/suite.png", "Luxury suite with living area and jacuzzi."},
                {"302", "SUITE", "images/suite.png", "Presidential suite with panoramic view."}
        };
        for (String[] d : data) {
            RoomCategory cat = RoomCategory.valueOf(d[1]);
            seed.add(new Room(d[0], cat, cat.getBasePrice(), true, d[2], d[3]));
        }
        saveRooms(seed);
    }

    // ---------------- Rooms ----------------

    public List<Room> loadRooms() {
        List<Room> rooms = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ROOMS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) rooms.add(Room.fromCsv(line));
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load rooms: " + e.getMessage(), e);
        }
        return rooms;
    }

    public void saveRooms(List<Room> rooms) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ROOMS_FILE))) {
            for (Room r : rooms) pw.println(r.toCsv());
        } catch (IOException e) {
            throw new RuntimeException("Failed to save rooms: " + e.getMessage(), e);
        }
    }

    // ---------------- Customers ----------------

    public List<Customer> loadCustomers() {
        List<Customer> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(CUSTOMERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) list.add(Customer.fromCsv(line));
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load customers: " + e.getMessage(), e);
        }
        return list;
    }

    public void saveCustomers(List<Customer> customers) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(CUSTOMERS_FILE))) {
            for (Customer c : customers) pw.println(c.toCsv());
        } catch (IOException e) {
            throw new RuntimeException("Failed to save customers: " + e.getMessage(), e);
        }
    }

    // ---------------- Reservations ----------------

    public List<Reservation> loadReservations() {
        List<Reservation> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RESERVATIONS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) list.add(Reservation.fromCsv(line));
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load reservations: " + e.getMessage(), e);
        }
        return list;
    }

    public void saveReservations(List<Reservation> reservations) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RESERVATIONS_FILE))) {
            for (Reservation r : reservations) pw.println(r.toCsv());
        } catch (IOException e) {
            throw new RuntimeException("Failed to save reservations: " + e.getMessage(), e);
        }
    }
}
