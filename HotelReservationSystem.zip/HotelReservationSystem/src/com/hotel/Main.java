package com.hotel;

import com.hotel.gui.LoginFrame;
import com.hotel.service.HotelService;

import javax.swing.*;

/**
 * Application entry point. Run this class from NetBeans (Run > Run File)
 * or via the command line.
 */
public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        SwingUtilities.invokeLater(() -> {
            HotelService service = new HotelService();
            new LoginFrame(service).setVisible(true);
        });
    }
}
