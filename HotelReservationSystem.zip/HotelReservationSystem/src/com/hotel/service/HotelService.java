package com.hotel.service;

import com.hotel.model.*;
import com.hotel.util.FileStorage;

import java.time.LocalDate;
import java.util.*;

/**
 * Core business logic: registration, login, room search, booking,
 * cancellation and payment simulation. Sits between the GUI and the
 * file-based storage layer (separation of concerns).
 */
public class HotelService {

    private final FileStorage storage = new FileStorage();

    private List<Room> rooms;
    private List<Customer> customers;
    private List<Reservation> reservations;

    public HotelService() {
        rooms = storage.loadRooms();
        customers = storage.loadCustomers();
        reservations = storage.loadReservations();
    }

    // ---------------- Authentication ----------------

    public boolean register(String username, String password, String fullName,
                             String email, String phone) {
        if (username == null || username.trim().isEmpty() || password == null || password.length() < 4) {
            throw new IllegalArgumentException("Username required and password must be at least 4 characters.");
        }
        for (Customer c : customers) {
            if (c.getUsername().equalsIgnoreCase(username)) {
                throw new IllegalArgumentException("Username already exists. Please choose another.");
            }
        }
        customers.add(new Customer(username, password, fullName, email, phone));
        storage.saveCustomers(customers);
        return true;
    }

    public Customer login(String username, String password) {
        for (Customer c : customers) {
            if (c.getUsername().equalsIgnoreCase(username) && c.getPassword().equals(password)) {
                return c;
            }
        }
        return null;
    }

    // ---------------- Rooms ----------------

    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms);
    }

    public List<Room> searchRooms(RoomCategory category, boolean onlyAvailable) {
        List<Room> result = new ArrayList<>();
        for (Room r : rooms) {
            boolean matchCategory = (category == null) || r.getCategory() == category;
            boolean matchAvail = !onlyAvailable || r.isAvailable();
            if (matchCategory && matchAvail) result.add(r);
        }
        return result;
    }

    private Room findRoom(String roomNumber) {
        for (Room r : rooms) {
            if (r.getRoomNumber().equals(roomNumber)) return r;
        }
        return null;
    }

    // ---------------- Booking ----------------

    public Reservation bookRoom(String username, String roomNumber, LocalDate checkIn,
                                 LocalDate checkOut, String cardNumber) {
        if (checkIn == null || checkOut == null || !checkOut.isAfter(checkIn)) {
            throw new IllegalArgumentException("Check-out date must be after check-in date.");
        }
        if (checkIn.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Check-in date cannot be in the past.");
        }
        Room room = findRoom(roomNumber);
        if (room == null) throw new IllegalArgumentException("Room not found.");
        if (!room.isAvailable()) throw new IllegalArgumentException("Selected room is not available.");
        if (cardNumber == null || cardNumber.replaceAll("\\s", "").length() < 12) {
            throw new IllegalArgumentException("Enter a valid card number to simulate payment (min 12 digits).");
        }

        long nights = java.time.temporal.ChronoUnit.DAYS.between(checkIn, checkOut);
        double total = nights * room.getPricePerNight();

        String resId = "RES" + System.currentTimeMillis();
        String last4 = cardNumber.replaceAll("\\s", "");
        last4 = last4.substring(last4.length() - 4);

        boolean paymentOk = simulatePayment(cardNumber, total);
        if (!paymentOk) throw new IllegalArgumentException("Payment simulation failed. Please try again.");

        Reservation res = new Reservation(resId, username, roomNumber, checkIn, checkOut,
                total, Reservation.Status.CONFIRMED, true, last4);
        reservations.add(res);
        room.setAvailable(false);

        storage.saveReservations(reservations);
        storage.saveRooms(rooms);
        return res;
    }

    private boolean simulatePayment(String cardNumber, double amount) {
        try { Thread.sleep(300); } catch (InterruptedException ignored) {}
        return cardNumber != null && cardNumber.replaceAll("\\s", "").matches("\\d{12,19}");
    }

    public List<Reservation> getReservationsForUser(String username) {
        List<Reservation> list = new ArrayList<>();
        for (Reservation r : reservations) {
            if (r.getUsername().equalsIgnoreCase(username)) list.add(r);
        }
        return list;
    }

    // ---------------- Cancellation & Refund ----------------

    public void cancelReservation(String reservationId) {
        for (Reservation r : reservations) {
            if (r.getReservationId().equals(reservationId)) {
                if (r.getStatus() == Reservation.Status.CANCELLED) {
                    throw new IllegalArgumentException("Reservation is already cancelled.");
                }
                r.setStatus(Reservation.Status.CANCELLED);
                Room room = findRoom(r.getRoomNumber());
                if (room != null) room.setAvailable(true);
                storage.saveReservations(reservations);
                storage.saveRooms(rooms);
                return;
            }
        }
        throw new IllegalArgumentException("Reservation not found.");
    }

    public boolean Cancelreservation(String reservationId) {
        for (Reservation r : reservations) {
            if (r.getReservationId().equals(reservationId)) {
                if (r.getStatus() == Reservation.Status.CANCELLED) {
                    throw new IllegalArgumentException("Reservation is already cancelled.");
                }
                r.setStatus(Reservation.Status.CANCELLED);
                
                Room room = findRoom(r.getRoomNumber());
                if (room != null) {
                    room.setAvailable(true); 
                }
                
                storage.saveReservations(reservations);
                storage.saveRooms(rooms);
                
                return true; 
            }
        }
        return false; 
    }

    // Yahan par Refund ka naya logic add hai jo payment ko 50% half kar dega
    public boolean refundReservation(String reservationId) {
        for (Reservation r : reservations) {
            if (r.getReservationId().equals(reservationId)) {
                if (r.getStatus() == Reservation.Status.REFUNDED || r.getStatus() == Reservation.Status.CANCELLED) {
                    throw new IllegalArgumentException("Reservation is already " + r.getStatus().toString().toLowerCase() + ".");
                }
                
                r.setStatus(Reservation.Status.REFUNDED);
                
                // PAYMENT KO HALF KARIEN
                r.setTotalAmount(r.getTotalAmount() * 0.5);
                
                Room room = findRoom(r.getRoomNumber());
                if (room != null) {
                    room.setAvailable(true); 
                }
                
                storage.saveReservations(reservations);
                storage.saveRooms(rooms);
                
                return true; 
            }
        }
        return false; 
    }
}