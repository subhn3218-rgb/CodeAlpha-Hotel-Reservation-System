package com.hotel.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.io.File;

public class ImageUtil {

    public static ImageIcon loadRoomImage(String category, int roomNumber, int width, int height) {

        String path = "";

        // Yahan par aap Har Room Number ke hisab se apne computer ki image ka path de sakte hain
        switch (category.toUpperCase()) {
            case "STANDARD":
                if (roomNumber == 101) {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.49 AM (2).jpg";
                } else if (roomNumber == 102) {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.50 AM (1).jpg";
                } else {
                    // Standard rooms ki default image (agar kisi room ka alag number ho)
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.48 AM.jpg";
                }
                break;

            case "DELUXE":
                if (roomNumber == 201) {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.51 AM (1).jpg";
                } else if (roomNumber == 202) {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.52 AM.jpg";
                } else {
                    path = "C:\\Users\\User\\Pictures\\deluxe_default.jpg";
                }
                break;

            case "SUITE":
                if (roomNumber == 301) {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.52 AM (1).jpg";
                } else if (roomNumber == 302) {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.52 AM (2).jpg";
                } else {
                    path = "C:\\Users\\User\\Pictures\\WhatsApp Image 2026-07-02 at 4.49.52 AM.jpg";
                }
                break;
        }

        return loadIcon(path, width, height, category, roomNumber);
    }

    public static ImageIcon loadIcon(String path, int width, int height, String category, int roomNumber) {
        try {
            File f = new File(path);
            if (f.exists()) {
                ImageIcon icon = new ImageIcon(path);
                Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                return new ImageIcon(img);
            }
        } catch (Exception ignored) {
        }

        // Agar file nahi mili ya path ghalat hai, to ek stylish placeholder return karega
        return placeholder(width, height, category, roomNumber);
    }

    // Ek stylish Placeholder jo Room ka Number aur Category ka Color show karega
    private static ImageIcon placeholder(int width, int height, String category, int roomNumber) {
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(
                width, height, java.awt.image.BufferedImage.TYPE_INT_ARGB);

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Category ke hisab se Color decide karna
        Color bgColor;
        switch (category.toUpperCase()) {
            case "STANDARD": bgColor = new Color(52, 152, 219); break; // Blue
            case "DELUXE":   bgColor = new Color(46, 204, 113); break; // Green
            case "SUITE":    bgColor = new Color(155, 89, 182); break; // Purple
            default:         bgColor = new Color(120, 144, 156); break; // Gray
        }

        // Rounded Box Draw karna
        g.setColor(bgColor);
        g.fill(new RoundRectangle2D.Float(0, 0, width, height, 20, 20));

        // Text Draw karna (Room Number)
        g.setColor(Color.WHITE);
        g.setFont(new Font("Segoe UI", Font.BOLD, 22));
        String text = "Rm " + roomNumber;
        FontMetrics fm = g.getFontMetrics();
        int x = (width - fm.stringWidth(text)) / 2;
        int y = (height - fm.getHeight()) / 2 + fm.getAscent();
        
        g.drawString(text, x, y);
        g.dispose();

        return new ImageIcon(img);
    }
}