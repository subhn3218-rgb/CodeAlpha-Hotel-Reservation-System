package com.hotel.gui;

import com.hotel.model.Customer;
import com.hotel.service.HotelService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Main window shown after a successful login. 
 * Acts as the primary dashboard for the Hotel Reservation System.
 */
public class MainFrame extends JFrame {

    private final HotelService service;
    private final Customer currentUser;

    public MainFrame(HotelService service, Customer currentUser) {
        this.service = service;
        this.currentUser = currentUser;

        setTitle("Hotel Reservation System - Welcome " + currentUser.getFullName());
        setSize(950, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 1. Main Panel with FULL BRIGHT Background Image (Removed the dark tint)
        JPanel mainPanel = new JPanel(new BorderLayout(20, 20)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw Background Image
                Image bg = new ImageIcon("C:\\Users\\User\\Pictures\\Screenshots\\WhatsApp Image 2026-07-02 at 4.49.49 AM (1).jpeg").getImage();
                if (bg != null) {
                    g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
                }
                // No black overlay here anymore. The image is now 100% bright and clear!
            }
        };
        mainPanel.setBorder(new EmptyBorder(30, 30, 30, 30));

        // 2. Header (Bold, Centered, White with a subtle drop-shadow for readability)
        JLabel headerLabel = new JLabel("Hotel Reservation Dashboard", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
                
                // Draw elegant dark drop-shadow so white text is readable on bright images
                g2.setColor(new Color(0, 0, 0, 180));
                g2.drawString(getText(), x + 3, y + 3);
                
                // Draw the actual white text
                g2.setColor(getForeground());
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 38));
        headerLabel.setForeground(Color.WHITE); 
        headerLabel.setBorder(new EmptyBorder(0, 0, 20, 0));
        mainPanel.add(headerLabel, BorderLayout.NORTH);

        // 3. Center 2x2 Grid using GridBagLayout
        JPanel gridPanel = new JPanel(new GridBagLayout());
        gridPanel.setOpaque(false); // Transparent so the bright background shows through
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20); // Spaced out for perfect symmetry
        gbc.fill = GridBagConstraints.BOTH;

        // Create 4 Large Action Buttons with distinct border colors
        JButton btnSearchBook = createGridButton("Search & Book Rooms", new Color(0, 123, 255));     // Blue Border
        JButton btnViewDetails = createGridButton("View Booking Details", new Color(23, 162, 184));  // Cyan Border
        JButton btnCancel = createGridButton("Cancel Reservation", new Color(253, 126, 20));         // Orange Border
        JButton btnRefund = createGridButton("Process 50% Refund", new Color(40, 167, 69));          // Green Border

        // --- Action Listeners (Opening New Windows) ---
        
        btnSearchBook.addActionListener(e -> {
            JFrame bookingFrame = new JFrame("Search & Book Rooms");
            bookingFrame.setSize(900, 700);
            bookingFrame.setLocationRelativeTo(this);
            // Pass bookingFrame::dispose as onBack so the "← Back" button
            // (already built into BookingPanel) becomes visible AND closes
            // this window, returning the user to MainFrame underneath.
            bookingFrame.add(new BookingPanel(service, currentUser, bookingFrame::dispose));
            bookingFrame.setVisible(true);
        });

        // VIEW BOOKING details kholne ke liye MyReservationsPanel (Read-Only)
        btnViewDetails.addActionListener(e -> {
            openReservationsWindow("My Booking Details");
        });

        // CANCEL RESERVATION kholne ke liye CancellationPanel (Jahan Cancel Button hoga)
        btnCancel.addActionListener(e -> {
            openCancellationWindow("Cancel Reservation");
        });

        // REFUND BUTTON: Ab yeh nayi RefundPanel class kholay ga!
        btnRefund.addActionListener(e -> {
            JFrame refundFrame = new JFrame("Process 50% Refund");
            refundFrame.setSize(950, 550);
            refundFrame.setLocationRelativeTo(this);
            refundFrame.add(new RefundPanel(service, currentUser));
            refundFrame.setVisible(true);
        });

        // Add buttons to GridBagLayout (2x2)
        gbc.gridx = 0; gbc.gridy = 0;
        gridPanel.add(btnSearchBook, gbc);

        gbc.gridx = 1; gbc.gridy = 0;
        gridPanel.add(btnViewDetails, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        gridPanel.add(btnCancel, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        gridPanel.add(btnRefund, gbc);

        mainPanel.add(gridPanel, BorderLayout.CENTER);

        // 4. Bottom Center - Log Out Button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setOpaque(false);
        bottomPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        
        // Custom Styled Log Out Button (Crimson Tint & Border)
        JButton btnLogout = new JButton("Log Out") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Subtle crimson tint background
                g2.setColor(new Color(220, 20, 60, 45)); 
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                
                // Sleek crimson border
                g2.setColor(new Color(220, 20, 60, 200));
                g2.setStroke(new BasicStroke(3f));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 25, 25);
                
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btnLogout.setPreferredSize(new Dimension(180, 45));
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 17));
        btnLogout.setForeground(Color.WHITE); 
        btnLogout.setFocusPainted(false);
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnLogout.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(this, 
                    "Are you sure you want to log out?", 
                    "Confirm Logout", JOptionPane.YES_NO_OPTION);
            
            if (choice == JOptionPane.YES_OPTION) {
                new LoginFrame(service).setVisible(true);
                dispose();
            }
        });
        
        bottomPanel.add(btnLogout);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    /**
     * Helper method to open the Reservations Window (Read-Only)
     */
    private void openReservationsWindow(String title) {
        JFrame resFrame = new JFrame(title);
        resFrame.setSize(900, 500);
        resFrame.setLocationRelativeTo(this);
        resFrame.add(new MyReservationsPanel(service, currentUser));
        resFrame.setVisible(true);
    }

    /**
     * Helper method to open the Cancellation Window (Has Cancel Button)
     */
    private void openCancellationWindow(String title) {
        JFrame cancelFrame = new JFrame(title);
        cancelFrame.setSize(900, 500);
        cancelFrame.setLocationRelativeTo(this);
        cancelFrame.add(new CancellationPanel(service, currentUser));
        cancelFrame.setVisible(true);
    }

    /**
     * Helper method to create elegant, semi-transparent white rounded buttons with specific border colors.
     */
    private JButton createGridButton(String text, Color borderColor) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                // Anti-aliasing for smooth rendering
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Sleek Semi-Transparent White inside background (approx 85% opacity)
                g2.setColor(new Color(255, 255, 255, 220)); 
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
                
                // Custom Colored Border
                g2.setColor(borderColor);
                g2.setStroke(new BasicStroke(4f)); // 4 pixels thick border
                g2.drawRoundRect(2, 2, getWidth() - 5, getHeight() - 5, 28, 28);
                
                g2.dispose();
                super.paintComponent(g);
            }
        };
        
        btn.setPreferredSize(new Dimension(280, 110)); // Increased dimensions so text can breathe
        btn.setFont(new Font("Segoe UI", Font.BOLD, 18)); 
        
        // Remove default button visuals to rely completely on our custom painting
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        
        btn.setForeground(new Color(30, 30, 30)); // Deep contrast gray text
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        return btn;
    }
}