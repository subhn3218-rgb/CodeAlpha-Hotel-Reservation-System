package com.hotel.gui;

import com.hotel.model.Customer;
import com.hotel.service.HotelService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginFrame extends JFrame {

    private final HotelService service;
    private JTextField loginUserField;
    private JPasswordField loginPassField;

    private final Font mainFont = new Font("Segoe UI", Font.BOLD, 18);
    private final Font inputFont = new Font("Times New Roman", Font.PLAIN, 18); 

    public LoginFrame(HotelService service) {
        this.service = service;
        setTitle("Hotel Reservation System - Sign In");
        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }

    private void initComponents() {
        // 1. Background Image Panel
        JPanel main = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image bg = new ImageIcon("C:\\Users\\User\\Pictures\\Screenshots\\WhatsApp Image 2026-06-30 at 3.46.08 AM.jpeg").getImage();
                if (bg != null) {
                    g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        // 2. Main Container 
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BorderLayout());
        formContainer.setOpaque(false); 
        formContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.RED, 2), 
                new EmptyBorder(20, 30, 20, 30) 
        ));

        // 3. Title 
        JLabel titleLabel = new JLabel("HOTEL RESERVATION SYSTEM");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        titleLabel.setForeground(Color.black); 
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(0, 0, 25, 0));
        formContainer.add(titleLabel, BorderLayout.NORTH);

        // 4. Center Content (Tabs + Fields)
        JPanel centerContent = new JPanel(new BorderLayout());
        centerContent.setOpaque(false);

        // Tab Bar 
        JPanel tabBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 10));
        tabBar.setOpaque(false);
        tabBar.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.white)); 
        
        JButton tabLogin = createTabButton("Sign In");
        JButton tabRegister = createTabButton("Sign Up");
        tabBar.add(tabLogin);
        tabBar.add(tabRegister);

        // CardLayout Holder
        JPanel cardHolder = new JPanel(new CardLayout());
        cardHolder.setOpaque(false); 
        cardHolder.add(buildLoginPanel(), "LOGIN");
        cardHolder.add(buildRegisterPanel(), "REGISTER");

        // Tab Switching Logic
        tabLogin.addActionListener(e -> {
            ((CardLayout)cardHolder.getLayout()).show(cardHolder, "LOGIN");
            tabLogin.setForeground(Color.white); 
            tabRegister.setForeground(new Color(100, 100, 100)); 
        });
        
        tabRegister.addActionListener(e -> {
            ((CardLayout)cardHolder.getLayout()).show(cardHolder, "REGISTER");
            tabRegister.setForeground(Color.white); 
            tabLogin.setForeground(new Color(100,100,100)); 
        });
        
        tabLogin.setForeground(Color.white);
        tabRegister.setForeground(new Color(100,100,100));

        centerContent.add(tabBar, BorderLayout.NORTH);
        
        JPanel paddingPanel = new JPanel(new BorderLayout());
        paddingPanel.setOpaque(false);
        paddingPanel.setBorder(new EmptyBorder(25, 0, 0, 0));
        paddingPanel.add(cardHolder, BorderLayout.CENTER);
        
        centerContent.add(paddingPanel, BorderLayout.CENTER);

        formContainer.add(centerContent, BorderLayout.CENTER);
        main.add(formContainer);
        setContentPane(main);
    }
    
    private JButton createTabButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 22)); 
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JPanel buildLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false); 
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 10, 15, 10); 

        // Username
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.fill = GridBagConstraints.NONE;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(mainFont);
        userLabel.setForeground(Color.white); 
        panel.add(userLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Taki dono boxes ki width same ho
        loginUserField = new JTextField(15);
        loginUserField.setFont(inputFont); 
        panel.add(loginUserField, gbc);

        // Password Label
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.fill = GridBagConstraints.NONE;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(mainFont);
        passLabel.setForeground(Color.white); 
        panel.add(passLabel, gbc);
        
        // Password Box (Eye Icon Inside)
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        loginPassField = new JPasswordField(15);
        loginPassField.setFont(inputFont); 
        loginPassField.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5)); // Remove default border to blend in

        // Wrapper creates the outer white box
        JPanel passWrapper = new JPanel(new BorderLayout());
        passWrapper.setBackground(Color.WHITE);
        passWrapper.setBorder(new JTextField().getBorder()); // Same border as normal TextField
        passWrapper.add(loginPassField, BorderLayout.CENTER);
        passWrapper.add(createDarkEyeToggleButton(loginPassField), BorderLayout.EAST); // Eye icon added to the right corner

        panel.add(passWrapper, gbc);

        // Login Button
        JButton loginBtn = new JButton("Sign In");
        styleButton(loginBtn);
        
        gbc.insets = new Insets(15, 10, 15, 10); 
        gbc.gridx = 0; gbc.gridy = 2; 
        gbc.gridwidth = 2; 
        gbc.anchor = GridBagConstraints.CENTER; 
        gbc.fill = GridBagConstraints.NONE;
        panel.add(loginBtn, gbc);

        loginBtn.addActionListener(e -> doLogin());
        loginPassField.addActionListener(e -> doLogin());

        return panel;
    }

    private JPanel buildRegisterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false); 
        
        GridBagConstraints gbc = new GridBagConstraints();

        JTextField nameField = new JTextField(15);
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JTextField emailField = new JTextField(15);
        JTextField phoneField = new JTextField(15);

        String[] labels = {"Full Name:", "Username:", "Password:", "Email:", "Phone:"};
        JComponent[] fields = {nameField, userField, passField, emailField, phoneField};

        for (int i = 0; i < labels.length; i++) {
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.gridx = 0; gbc.gridy = i;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.EAST;
            gbc.fill = GridBagConstraints.NONE;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(mainFont);
            lbl.setForeground(Color.white); 
            panel.add(lbl, gbc);
            
            gbc.gridx = 1;
            gbc.anchor = GridBagConstraints.WEST;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            
            if (fields[i] == passField) {
                passField.setFont(inputFont);
                passField.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
                
                JPanel passWrapper = new JPanel(new BorderLayout());
                passWrapper.setBackground(Color.WHITE);
                passWrapper.setBorder(new JTextField().getBorder());
                passWrapper.add(passField, BorderLayout.CENTER);
                passWrapper.add(createDarkEyeToggleButton(passField), BorderLayout.EAST);
                
                panel.add(passWrapper, gbc);
            } else {
                fields[i].setFont(inputFont); 
                panel.add(fields[i], gbc);
            }
        }

        JButton registerBtn = new JButton("Create Account");
        styleButton(registerBtn);
        
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0; gbc.gridy = labels.length; 
        gbc.gridwidth = 2; 
        gbc.anchor = GridBagConstraints.CENTER; 
        gbc.fill = GridBagConstraints.NONE;
        panel.add(registerBtn, gbc);

        registerBtn.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                String user = userField.getText().trim();
                String pass = new String(passField.getPassword());
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();

                if (name.isEmpty()) throw new IllegalArgumentException("Full name is required.");
                if (!email.matches("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$")) {
                    throw new IllegalArgumentException("Enter a valid email address.");
                }
                if (!phone.matches("\\d{7,15}")) {
                    throw new IllegalArgumentException("Enter a valid phone number (digits only).");
                }
                service.register(user, pass, name, email, phone);
                JOptionPane.showMessageDialog(this, "Account created successfully! Please sign in.");
                nameField.setText(""); userField.setText(""); passField.setText("");
                emailField.setText(""); phoneField.setText("");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // ================= DARK EYE ICON (INSIDE TEXT FIELD) =================
    private JToggleButton createDarkEyeToggleButton(JPasswordField passField) {
        final char defaultEchoChar = passField.getEchoChar();
        
        JToggleButton toggleBtn = new JToggleButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int w = getWidth();
                int h = getHeight();
                
                // Color dark grey so it's visible on white background
                g2.setColor(getModel().isRollover() ? Color.BLACK : new Color(100, 100, 100));
                g2.setStroke(new BasicStroke(2f));
                
                int cx = w / 2;
                int cy = h / 2;
                int rx = 8;
                int ry = 5;
                
                // Eye Shape
                g2.drawArc(cx - rx, cy - ry, rx * 2, ry * 2, 0, 180);
                g2.drawArc(cx - rx, cy - ry, rx * 2, ry * 2, 180, 180);
                
                // Pupil
                g2.fillOval(cx - 2, cy - 2, 4, 4);
                
                // Cross line when password is shown
                if (isSelected()) { 
                    g2.drawLine(cx - 10, cy - 8, cx + 10, cy + 8);
                }
                
                g2.dispose();
            }
        };
        
        toggleBtn.setContentAreaFilled(false);
        toggleBtn.setBorderPainted(false);
        toggleBtn.setFocusPainted(false);
        toggleBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        toggleBtn.setPreferredSize(new Dimension(30, 24)); // Adequate click area
        toggleBtn.setToolTipText("Show/Hide Password");

        toggleBtn.addActionListener(e -> {
            if (toggleBtn.isSelected()) {
                passField.setEchoChar((char) 0); // Show Password
            } else {
                passField.setEchoChar(defaultEchoChar); // Hide Password
            }
        });

        return toggleBtn;
    }

    private void doLogin() {
        String user = loginUserField.getText().trim();
        String pass = new String(loginPassField.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Customer customer = service.login(user, pass);
        if (customer == null) {
            JOptionPane.showMessageDialog(this, "Invalid username or password.",
                    "Sign In Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, "Welcome back, " + customer.getFullName() + "!");
        new MainFrame(service, customer).setVisible(true);
        dispose();
    }

    private void styleButton(JButton btn) {
        btn.setBackground(Color.BLACK); 
        btn.setForeground(Color.WHITE); 
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        
        btn.setUI(new javax.swing.plaf.basic.BasicButtonUI());
        btn.setFocusPainted(false);
        
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(180, 40)); 

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(60, 60, 60)); // Hover
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(Color.BLACK); // Normal
            }
        });
    }
}