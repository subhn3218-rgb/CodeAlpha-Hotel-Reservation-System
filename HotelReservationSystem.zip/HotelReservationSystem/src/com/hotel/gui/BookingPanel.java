package com.hotel.gui;

import com.hotel.model.Customer;
import com.hotel.model.Room;
import com.hotel.model.RoomCategory;
import com.hotel.service.HotelService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class BookingPanel extends JPanel {

    private final HotelService service;
    private final Customer currentUser;
    private final Runnable onBack;

    private JComboBox<String> categoryCombo;
    private JCheckBox onlyAvailableCheck;
    private JPanel resultsContainer;

    // ==================== PREMIUM COLOR PALETTE ====================
    // Background gradient colors
    private final Color bgTop    = new Color(15, 23, 42);      // Deep navy
    private final Color bgBottom = new Color(30, 41, 59);      // Slightly lighter navy

    // Card colors
    private final Color cardBg   = new Color(30, 41, 59);      // Dark card
    private final Color cardBorder= new Color(51, 65, 85);     // Subtle border

    // Category strip colors
    private final Color stdColor  = new Color(59, 130, 246);   // Blue
    private final Color dlxColor  = new Color(16, 185, 129);   // Emerald
    private final Color suitColor = new Color(168, 85, 247);   // Violet

    // Text colors
    private final Color textPrimary   = new Color(241, 245, 249); // Almost white
    private final Color textSecondary = new Color(148, 163, 184); // Slate gray
    private final Color priceColor    = new Color(52, 211, 153);  // Mint green
    private final Color availColor    = new Color(52, 211, 153);  // Green
    private final Color bookedColor   = new Color(248, 113, 113); // Soft red

    // Filter bar
    private final Color filterBg    = new Color(30, 41, 59);
    private final Color filterBorder= new Color(71, 85, 105);

    // Popup dialog
    private final Color popupBg     = new Color(15, 23, 42);
    private final Color fieldBg     = new Color(30, 41, 59);
    private final Color fieldBorder = new Color(71, 85, 105);

    public BookingPanel(HotelService service, Customer currentUser, Runnable onBack) {
        this.service     = service;
        this.currentUser = currentUser;
        this.onBack      = onBack;

        setLayout(new BorderLayout(15, 15));
        setOpaque(false); // gradient background ke liye
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(buildTopBar(), BorderLayout.NORTH);

        resultsContainer = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                // Transparent so gradient shows through
                setOpaque(false);
                super.paintComponent(g);
            }
        };
        resultsContainer.setLayout(new BoxLayout(resultsContainer, BoxLayout.Y_AXIS));
        resultsContainer.setOpaque(false);

        JScrollPane scrollPane = new JScrollPane(resultsContainer) {
            @Override
            protected void paintComponent(Graphics g) {
                setOpaque(false);
                super.paintComponent(g);
            }
        };
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                this.thumbColor = new Color(99, 102, 241, 180);
                this.trackColor = new Color(30, 41, 59);
            }
            @Override protected JButton createDecreaseButton(int o) { return zeroBtn(); }
            @Override protected JButton createIncreaseButton(int o) { return zeroBtn(); }
            private JButton zeroBtn() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                if (r.isEmpty() || !scrollbar.isEnabled()) return;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(thumbColor);
                g2.fillRoundRect(r.x + 1, r.y + 1, r.width - 2, r.height - 2, 8, 8);
                g2.dispose();
            }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(trackColor);
                g2.fillRect(r.x, r.y, r.width, r.height);
                g2.dispose();
            }
        });

        add(scrollPane, BorderLayout.CENTER);
        loadRooms(null, false);
    }

    public BookingPanel(HotelService service, Customer currentUser) {
        this(service, currentUser, null);
    }

    // ==================== GRADIENT BACKGROUND ====================
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint gp = new GradientPaint(0, 0, bgTop, 0, getHeight(), bgBottom);
        g2.setPaint(gp);
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
    }

    // ==================== TOP BAR ====================
    private JPanel buildTopBar() {
        JPanel topBar = new JPanel(new BorderLayout(10, 0));
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(0, 0, 10, 0));

        if (onBack != null) {
            JButton backBtn = buildGlassButton("← Back", new Color(99, 102, 241), new Color(79, 70, 229));
            backBtn.setPreferredSize(new Dimension(110, 40));
            backBtn.addActionListener(e -> onBack.run());
            topBar.add(backBtn, BorderLayout.WEST);
        }

        topBar.add(buildFilterBar(), BorderLayout.CENTER);
        return topBar;
    }

    private JPanel buildFilterBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(filterBg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.setColor(filterBorder);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBorder(new EmptyBorder(8, 12, 8, 12));

        JLabel lblCat = new JLabel("Category:");
        lblCat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCat.setForeground(Color.white);
        lblCat.setBackground(Color.black);
        bar.add(lblCat);

        categoryCombo = new JComboBox<>(new String[]{"All", "Standard", "Deluxe", "Suite"});
        categoryCombo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        categoryCombo.setBackground(new Color(51, 65, 85));
        categoryCombo.setForeground(Color.black);
        categoryCombo.setPreferredSize(new Dimension(140, 34));
        bar.add(categoryCombo);

        onlyAvailableCheck = new JCheckBox("Only Available");
        onlyAvailableCheck.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        onlyAvailableCheck.setSelected(true);
        onlyAvailableCheck.setOpaque(false);
        onlyAvailableCheck.setForeground(textSecondary);
        bar.add(onlyAvailableCheck);

        JButton searchBtn = buildGlassButton("Search Rooms", new Color(59, 130, 246), new Color(37, 99, 235));
        searchBtn.addActionListener(e -> applyFilter());
        bar.add(searchBtn);

        return bar;
    }

    private void applyFilter() {
        RoomCategory cat = null;
        String sel = (String) categoryCombo.getSelectedItem();
        if (sel != null && !sel.equals("All")) {
            cat = RoomCategory.valueOf(sel.toUpperCase());
        }
        loadRooms(cat, onlyAvailableCheck.isSelected());
    }

    // ==================== ROOM LIST ====================
    private void loadRooms(RoomCategory category, boolean onlyAvailable) {
        resultsContainer.removeAll();
        List<Room> rooms = service.searchRooms(category, onlyAvailable);

        if (rooms.isEmpty()) {
            JLabel noRooms = new JLabel("No rooms match your search criteria.");
            noRooms.setFont(new Font("Segoe UI", Font.ITALIC, 16));
            noRooms.setForeground(textSecondary);
            noRooms.setBorder(new EmptyBorder(40, 20, 20, 20));
            noRooms.setAlignmentX(Component.CENTER_ALIGNMENT);
            resultsContainer.add(noRooms);
        } else {
            for (Room room : rooms) {
                resultsContainer.add(buildRoomCard(room));
                resultsContainer.add(Box.createVerticalStrut(14));
            }
        }
        resultsContainer.revalidate();
        resultsContainer.repaint();
    }

    // ==================== ROOM CARD ====================
    private JPanel buildRoomCard(Room room) {
        Color strip = categoryStrip(room.getCategory().name());

        JPanel card = new JPanel(new BorderLayout(16, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Card background
                g2.setColor(cardBg);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);

                // Left colored strip
                g2.setColor(strip);
                g2.fillRoundRect(0, 0, 7, getHeight() - 1, 16, 16);
                g2.fillRect(5, 0, 2, getHeight());

                // Card border
                g2.setColor(cardBorder);
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);

                // Top color glow effect
                GradientPaint glow = new GradientPaint(
                        0, 0, new Color(strip.getRed(), strip.getGreen(), strip.getBlue(), 30),
                        0, 60, new Color(0, 0, 0, 0));
                g2.setPaint(glow);
                g2.fillRoundRect(0, 0, getWidth() - 1, 60, 16, 16);

                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(14, 22, 14, 18));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 145));

        // ---- Room Image ----
        int roomNumInt;
        try {
            roomNumInt = Integer.parseInt(room.getRoomNumber().replaceAll("[^0-9]", ""));
        } catch (NumberFormatException ex) {
            roomNumInt = 0;
        }
        ImageIcon roomImg = ImageUtil.loadRoomImage(room.getCategory().name(), roomNumInt, 105, 88);
        JLabel iconLabel = new JLabel(roomImg);
        iconLabel.setPreferredSize(new Dimension(112, 88));

        // Rounded image wrapper
        JPanel imgWrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(15, 23, 42));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        imgWrapper.setOpaque(false);
        imgWrapper.add(iconLabel, BorderLayout.CENTER);
        imgWrapper.setPreferredSize(new Dimension(112, 90));
        card.add(imgWrapper, BorderLayout.WEST);

        // ---- Info panel ----
        JLabel title = new JLabel("Room " + room.getRoomNumber() + "  —  " + room.getCategory().getDisplayName());
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(textPrimary);

        JLabel price = new JLabel("Rs. " + room.getPricePerNight() + "  /  night");
        price.setFont(new Font("Segoe UI", Font.BOLD, 14));
        price.setForeground(priceColor);

        int maxGuests = room.getMaxGuests();
        JLabel desc = new JLabel(room.getDescription() + "   |   Max " + maxGuests + " guest" + (maxGuests == 1 ? "" : "s"));
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        desc.setForeground(textSecondary);

        // Status badge
        boolean avail = room.isAvailable();
        JLabel status = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = avail ? new Color(16, 185, 129, 30) : new Color(239, 68, 68, 30);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        status.setText(avail ? "  ● Available  " : "  ● Booked  ");
        status.setFont(new Font("Segoe UI", Font.BOLD, 12));
        status.setForeground(avail ? availColor : bookedColor);
        status.setPreferredSize(new Dimension(100, 26));
        status.setOpaque(false);

        JPanel statusWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        statusWrap.setOpaque(false);
        statusWrap.add(status);

        JPanel info = new JPanel(new GridLayout(4, 1, 0, 3));
        info.setOpaque(false);
        info.add(title);
        info.add(price);
        info.add(desc);
        info.add(statusWrap);
        card.add(info, BorderLayout.CENTER);

        // ---- Book button ----
        JButton bookBtn = buildBookButton(room.isAvailable(), strip);
        if (room.isAvailable()) {
            bookBtn.addActionListener(e -> openBookingDialog(room));
        }
        JPanel btnWrap = new JPanel(new GridBagLayout());
        btnWrap.setOpaque(false);
        btnWrap.add(bookBtn);
        card.add(btnWrap, BorderLayout.EAST);

        return card;
    }

    private Color categoryStrip(String categoryName) {
        switch (categoryName.toUpperCase()) {
            case "STANDARD": return stdColor;
            case "DELUXE":   return dlxColor;
            case "SUITE":    return suitColor;
            default:         return new Color(100, 116, 139);
        }
    }

    // ==================== BOOK BUTTON ====================
    private JButton buildBookButton(boolean available, Color accentColor) {
        JButton btn = new JButton(available ? "Book Now" : "Booked") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (!available) {
                    g2.setColor(new Color(51, 65, 85));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
                    g2.setColor(new Color(71, 85, 105));
                    g2.setStroke(new BasicStroke(1.5f));
                    g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 22, 22);
                } else {
                    boolean hover = Boolean.TRUE.equals(getClientProperty("hover"));
                    Color c1 = hover ? accentColor.brighter() : accentColor;
                    Color c2 = hover ? accentColor : accentColor.darker();
                    GradientPaint gp = new GradientPaint(0, 0, c1, 0, getHeight(), c2);
                    g2.setPaint(gp);
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setPreferredSize(new Dimension(130, 42));
        btn.setEnabled(available);
        btn.setForeground(available ? Color.WHITE : new Color(100, 116, 139));
        btn.setCursor(available ? new Cursor(Cursor.HAND_CURSOR) : new Cursor(Cursor.DEFAULT_CURSOR));

        if (available) {
            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override public void mouseEntered(java.awt.event.MouseEvent e) { btn.putClientProperty("hover", true);  btn.repaint(); }
                @Override public void mouseExited(java.awt.event.MouseEvent e)  { btn.putClientProperty("hover", false); btn.repaint(); }
            });
        }
        return btn;
    }

    // ==================== BOOKING DIALOG ====================
    private void openBookingDialog(Room room) {
        Frame owner = null;
        Window ancestor = SwingUtilities.getWindowAncestor(this);
        if (ancestor instanceof Frame) owner = (Frame) ancestor;

        JDialog dialog = new JDialog(owner, "Secure Booking — Room " + room.getRoomNumber(), true);
        dialog.setSize(500, 600);
        dialog.setLocationRelativeTo(ancestor);
        dialog.setResizable(false);

        // Dark popup background
        JPanel dialogBg = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(15, 23, 42), 0, getHeight(), new Color(23, 37, 60));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        dialogBg.setOpaque(true);
        dialogBg.setBorder(new EmptyBorder(25, 30, 25, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill    = GridBagConstraints.HORIZONTAL;
        gbc.gridx   = 0;
        gbc.weightx = 1.0;
        gbc.insets  = new Insets(5, 0, 5, 0);

        int row = 0;
        Color strip = categoryStrip(room.getCategory().name());

        // --- Colored Header Strip ---
        JPanel headerStrip = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, strip, getWidth(), 0, strip.darker());
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
            }
        };
        headerStrip.setOpaque(false);
        headerStrip.setLayout(new BorderLayout());
        headerStrip.setBorder(new EmptyBorder(12, 16, 12, 16));
        headerStrip.setPreferredSize(new Dimension(0, 60));

        JLabel header = new JLabel("Book Room " + room.getRoomNumber());
        header.setFont(new Font("Segoe UI", Font.BOLD, 20));
        header.setForeground(Color.WHITE);

        JLabel subHeader = new JLabel(room.getCategory().getDisplayName()
                + "  ·  Rs." + room.getPricePerNight() + "/night"
                + "  ·  Max " + room.getMaxGuests() + " guests");
        subHeader.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subHeader.setForeground(new Color(255, 255, 255, 180));

        JPanel headerTexts = new JPanel(new GridLayout(2, 1, 0, 2));
        headerTexts.setOpaque(false);
        headerTexts.add(header);
        headerTexts.add(subHeader);
        headerStrip.add(headerTexts, BorderLayout.CENTER);

        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 18, 0);
        dialogBg.add(headerStrip, gbc);

        // --- Fields ---
        gbc.insets = new Insets(4, 0, 4, 0);

        gbc.gridy = row++;
        dialogBg.add(fieldLabel("Guest Name"), gbc);
        gbc.gridy = row++;
        JTextField guestNameField = createDarkTextField(currentUser.getFullName());
        dialogBg.add(guestNameField, gbc);

        gbc.gridy = row++;
        dialogBg.add(fieldLabel("Number of Guests  (max " + room.getMaxGuests() + ")"), gbc);
        gbc.gridy = row++;
        JTextField numGuestsField = createDarkTextField("1");
        dialogBg.add(numGuestsField, gbc);

        gbc.gridy = row++;
        dialogBg.add(fieldLabel("Check-in Date  (YYYY-MM-DD)"), gbc);
        gbc.gridy = row++;
        JTextField checkInField = createDarkTextField(LocalDate.now().plusDays(1).toString());
        dialogBg.add(checkInField, gbc);

        gbc.gridy = row++;
        dialogBg.add(fieldLabel("Check-out Date  (YYYY-MM-DD)"), gbc);
        gbc.gridy = row++;
        JTextField checkOutField = createDarkTextField(LocalDate.now().plusDays(2).toString());
        dialogBg.add(checkOutField, gbc);

        gbc.gridy = row++;
        dialogBg.add(fieldLabel("Card Number  (Simulation)"), gbc);
        gbc.gridy = row++;
        JTextField cardField = createDarkTextField("");
        dialogBg.add(cardField, gbc);

        // --- Two Bottom Buttons ---
        gbc.gridy = row++;
        gbc.insets = new Insets(20, 0, 0, 0);

        JPanel btnRow = new JPanel(new GridLayout(1, 2, 12, 0));
        btnRow.setOpaque(false);

        // Cancel button (gray)
        JButton cancelBtn = buildGlassButton("Cancel", new Color(71, 85, 105), new Color(51, 65, 85));
        cancelBtn.addActionListener(e -> dialog.dispose());

        // Confirm button (colored, same as strip)
        JButton confirmBtn = buildGlassButton("Confirm Payment", strip, strip.darker());
        btnRow.add(cancelBtn);
        btnRow.add(confirmBtn);
        dialogBg.add(btnRow, gbc);

        // --- Booking Logic ---
        confirmBtn.addActionListener(e -> {
            String guestName    = guestNameField.getText().trim();
            String numGuestsStr = numGuestsField.getText().trim();
            String checkInStr   = checkInField.getText().trim();
            String checkOutStr  = checkOutField.getText().trim();
            String cardStr      = cardField.getText().trim();

            if (guestName.isEmpty()) { showError(dialog, "Please enter the guest name."); return; }

            int numGuests;
            try {
                numGuests = Integer.parseInt(numGuestsStr);
                if (numGuests < 1) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                showError(dialog, "Please enter a valid number of guests (at least 1)."); return;
            }
            if (numGuests > room.getMaxGuests()) {
                showError(dialog, "Max " + room.getMaxGuests() + " guest(s) allowed."); return;
            }

            LocalDate checkIn, checkOut;
            try {
                checkIn  = LocalDate.parse(checkInStr);
                checkOut = LocalDate.parse(checkOutStr);
            } catch (java.time.format.DateTimeParseException dpe) {
                showError(dialog, "Please enter valid dates in YYYY-MM-DD format."); return;
            }
            if (!checkOut.isAfter(checkIn)) { showError(dialog, "Check-out must be after check-in."); return; }
            if (!checkIn.isAfter(LocalDate.now())) { showError(dialog, "Check-in must be a future date."); return; }
            if (cardStr.isEmpty() || !cardStr.matches("\\d{13,19}")) {
                showError(dialog, "Enter a valid card number (13–19 digits)."); return;
            }

            try {
                var res = service.bookRoom(currentUser.getUsername(), room.getRoomNumber(), checkIn, checkOut, cardStr);
                dialog.dispose();
                long nights = java.time.temporal.ChronoUnit.DAYS.between(checkIn, checkOut);
                JOptionPane.showMessageDialog(this,
                        "✅  Booking Confirmed!\n\n"
                        + "Reservation ID : " + res.getReservationId() + "\n"
                        + "Guest Name     : " + guestName + "\n"
                        + "Guests         : " + numGuests + "\n"
                        + "Room           : " + room.getRoomNumber() + "\n"
                        + "Check-in       : " + checkIn + "\n"
                        + "Check-out      : " + checkOut + "\n"
                        + "Nights         : " + nights + "\n"
                        + "Total Paid     : Rs. " + res.getTotalAmount() + "\n"
                        + "Card ending in : " + res.getCardLast4(),
                        "Payment Successful", JOptionPane.INFORMATION_MESSAGE);
                applyFilter();
            } catch (IllegalArgumentException ex) {
                showError(dialog, ex.getMessage());
            }
        });

        dialog.setContentPane(new JScrollPane(dialogBg) {{
            setBorder(BorderFactory.createEmptyBorder());
            setOpaque(false);
            getViewport().setOpaque(false);
        }});
        dialog.setVisible(true);
    }

    // ==================== HELPERS ====================

    private JLabel fieldLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(new Color(148, 163, 184));
        return lbl;
    }

    private void showError(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Validation Error", JOptionPane.ERROR_MESSAGE);
    }

    // Dark-themed text field
    private JTextField createDarkTextField(String defaultText) {
        JTextField tf = new JTextField(defaultText) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fieldBg);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.setColor(fieldBorder);
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        tf.setOpaque(false);
        tf.setForeground(textPrimary);
        tf.setCaretColor(Color.WHITE);
        tf.setBorder(new EmptyBorder(9, 14, 9, 14));
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setPreferredSize(new Dimension(0, 42));
        return tf;
    }

    // Reusable stylish gradient button
    private JButton buildGlassButton(String text, Color c1, Color c2) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean hover = Boolean.TRUE.equals(getClientProperty("hover"));
                Color top = hover ? c1.brighter() : c1;
                Color bot = hover ? c2.brighter() : c2;
                GradientPaint gp = new GradientPaint(0, 0, top, 0, getHeight(), bot);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setBorder(new EmptyBorder(10, 18, 10, 18));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { btn.putClientProperty("hover", true);  btn.repaint(); }
            @Override public void mouseExited(java.awt.event.MouseEvent e)  { btn.putClientProperty("hover", false); btn.repaint(); }
        });
        return btn;
    }
}