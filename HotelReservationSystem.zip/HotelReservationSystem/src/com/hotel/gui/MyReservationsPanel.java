package com.hotel.gui;

import com.hotel.model.Customer;
import com.hotel.model.Reservation;
import com.hotel.service.HotelService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class MyReservationsPanel extends JPanel {

    private final HotelService service;
    private final Customer currentUser;
    private final Runnable onBack;

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel statusLabel;

    // ================= DARK NAVY DASHBOARD PALETTE =================
    private final Color pageBg         = new Color(15, 23, 42);    // Slate-900 overall background
    private final Color panelBg        = new Color(21, 30, 50);    // Card / header panel background
    private final Color panelBorder    = new Color(40, 51, 78);    // Subtle card border
    private final Color headerBg       = new Color(21, 30, 50);    // Table header row background
    private final Color headerText     = new Color(148, 163, 184); // Slate-400 column labels
    private final Color rowColor       = new Color(21, 30, 50);    // Row (even)
    private final Color rowAltColor    = new Color(27, 37, 59);    // Row (odd, zebra stripe)
    private final Color gridColor      = new Color(40, 51, 78);
    private final Color firstColBg     = new Color(30, 41, 59);    // locked/static column
    private final Color firstColAltBg  = new Color(36, 47, 68);
    private final Color textColor      = new Color(226, 232, 240); // Slate-200 body text
    private final Color textMuted      = new Color(148, 163, 184); // Slate-400 subtitle text
    private final Color selectionBg    = new Color(37, 99, 235);   // Professional blue
    private final Color selectionFg    = Color.WHITE;

    private final Color accent         = new Color(37, 99, 235);   // Blue accent
    private final Color accentHover    = new Color(29, 78, 216);
    private final Color accentPressed  = new Color(23, 61, 179);

    // Status "mix palette" accent colors (dark pill badges)
    private final Color confirmedBg = new Color(6, 78, 59);
    private final Color confirmedFg = new Color(110, 231, 183);
    private final Color cancelledBg = new Color(76, 29, 33);
    private final Color cancelledFg = new Color(252, 165, 165);
    private final Color pendingBg   = new Color(76, 58, 15);
    private final Color pendingFg   = new Color(252, 211, 77);
    private final Color refundedBg  = new Color(49, 39, 96);
    private final Color refundedFg  = new Color(196, 181, 253);

    // Status bar feedback colors
    private final Color statusIdleColor = textMuted;

    // Backward-compatible constructor
    public MyReservationsPanel(HotelService service, Customer currentUser) {
        this(service, currentUser, null);
    }

    // Constructor with a back-navigation callback
    public MyReservationsPanel(HotelService service, Customer currentUser, Runnable onBack) {
        this.service = service;
        this.currentUser = currentUser;
        this.onBack = onBack;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        setBackground(pageBg);

        String[] columns = {
                "Reservation ID", "Room No.", "Check-in", "Check-out",
                "Nights", "Total (Rs.)", "Status", "Paid"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        styleScrollPane(scrollPane);

        // Add Header and Table (Table must be initialized before Header for search box)
        add(buildHeaderBar(), BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);

        refresh();
    }

    // ================= HEADER BAR =================
    private JPanel buildHeaderBar() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(panelBg);
        wrapper.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(panelBorder, 1),
                new EmptyBorder(18, 20, 18, 20)
        ));

        JPanel accentStripe = new JPanel();
        accentStripe.setBackground(accent);
        accentStripe.setPreferredSize(new Dimension(4, 10));

        JPanel textCol = new JPanel();
        textCol.setOpaque(false);
        textCol.setLayout(new BoxLayout(textCol, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("My Reservations");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("View your booking history and current status.");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(textMuted);
        subtitle.setBorder(new EmptyBorder(4, 0, 0, 0));

        textCol.add(title);
        textCol.add(subtitle);

        // Back button
        JButton backBtn = buildProfessionalButton("\u2190 Back", new Color(51, 65, 85), new Color(71, 85, 105), new Color(30, 41, 59));
        backBtn.addActionListener(e -> {
            if (onBack != null) {
                onBack.run();
            } else {
                Window w = SwingUtilities.getWindowAncestor(this);
                if (w != null) {
                    w.setVisible(false);
                    w.dispose();
                }
            }
        });

        JPanel left = new JPanel(new BorderLayout(14, 0));
        left.setOpaque(false);

        JPanel backAndStripe = new JPanel(new BorderLayout(14, 0));
        backAndStripe.setOpaque(false);
        backAndStripe.add(backBtn, BorderLayout.WEST);
        backAndStripe.add(accentStripe, BorderLayout.EAST);

        left.add(backAndStripe, BorderLayout.WEST);
        left.add(textCol, BorderLayout.CENTER);

        // SEARCH FIELD UI
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchPanel.setOpaque(false);
        searchPanel.setBorder(new EmptyBorder(4, 0, 0, 0));

        JLabel searchLabel = new JLabel("Find ID:");
        searchLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        searchLabel.setForeground(textMuted);

        JTextField searchField = new JTextField(12);
        searchField.setBackground(new Color(30, 41, 59));
        searchField.setForeground(Color.WHITE);
        searchField.setCaretColor(Color.WHITE);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(71, 85, 105), 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Logic to highlight the matching row based on what's typed
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { searchRow(); }
            @Override public void removeUpdate(DocumentEvent e) { searchRow(); }
            @Override public void changedUpdate(DocumentEvent e) { searchRow(); }

            private void searchRow() {
                String text = searchField.getText().trim().toLowerCase();
                if (text.isEmpty()) {
                    table.clearSelection();
                    return;
                }
                for (int i = 0; i < table.getRowCount(); i++) {
                    Object val = table.getValueAt(i, 0); // Column 0 is Reservation ID
                    if (val != null && val.toString().toLowerCase().startsWith(text)) {
                        table.setRowSelectionInterval(i, i);
                        table.scrollRectToVisible(table.getCellRect(i, 0, true)); // Auto scroll to row
                        return;
                    }
                }
                table.clearSelection(); // Clear if no match found
            }
        });

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);

        JPanel rightControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        rightControls.setOpaque(false);
        rightControls.add(searchPanel);
        rightControls.add(buildListIcon());

        wrapper.add(left, BorderLayout.WEST);
        wrapper.add(rightControls, BorderLayout.EAST);

        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        outer.add(wrapper, BorderLayout.CENTER);
        outer.setBorder(new EmptyBorder(0, 0, 15, 0));
        return outer;
    }

    private JComponent buildListIcon() {
        JComponent icon = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 40));
                g2.fillOval(0, 0, getWidth(), getHeight());

                g2.setStroke(new BasicStroke(2.2f));
                g2.setColor(accent);
                int left = 11, right = getWidth() - 11;
                int y1 = 13, y2 = 19, y3 = 25;
                g2.drawLine(left, y1, right, y1);
                g2.drawLine(left, y2, right, y2);
                g2.drawLine(left, y3, right, y3);
                g2.dispose();
            }
        };
        icon.setPreferredSize(new Dimension(38, 38));
        icon.setOpaque(false);
        return icon;
    }

    // ================= BOTTOM BAR =================
    private JPanel buildBottomBar() {
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(pageBg);
        bottom.setBorder(BorderFactory.createEmptyBorder(10, 4, 0, 0));

        statusLabel = new JLabel(" ");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        statusLabel.setForeground(statusIdleColor);
        bottom.add(statusLabel, BorderLayout.WEST);

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonRow.setOpaque(false);

        JButton refreshBtn = buildProfessionalButton("\u27F3 Refresh", accent, accentHover, accentPressed);
        refreshBtn.addActionListener(e -> {
            refresh();
            setStatusMessage("Table refreshed.", statusIdleColor);
        });

        buttonRow.add(refreshBtn);

        bottom.add(buttonRow, BorderLayout.EAST);
        return bottom;
    }

    private void setStatusMessage(String message, Color color) {
        statusLabel.setForeground(color);
        statusLabel.setText(message);
    }

    // ================= PROFESSIONAL BUTTON =================
    private JButton buildProfessionalButton(String label, Color base, Color hover, Color pressed) {
        JButton btn = new JButton(label) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                Color bg = base;
                if (getModel().isPressed()) {
                    bg = pressed;
                } else if (getModel().isRollover()) {
                    bg = hover;
                }

                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };

        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder(9, 24, 9, 24));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // ================= TABLE STYLE =================
    private void styleTable(JTable table) {

        table.setRowHeight(32);
        table.setShowGrid(true);
        table.setGridColor(gridColor);
        table.setIntercellSpacing(new Dimension(1, 1));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setBackground(rowColor);
        table.setForeground(textColor);
        table.setSelectionBackground(selectionBg);
        table.setSelectionForeground(selectionFg);

        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(0, 42));
        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);
        header.setOpaque(false);

        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, false, false, row, column);

                label.setOpaque(true);
                label.setBackground(headerBg);
                label.setForeground(headerText);
                label.setFont(new Font("Segoe UI", Font.BOLD, 13));
                label.setHorizontalAlignment(SwingConstants.LEFT);
                label.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 2, 1, gridColor),
                        BorderFactory.createEmptyBorder(0, 12, 0, 12)));
                return label;
            }
        });

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {

                Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                String colName = table.getColumnName(column);
                String text = value == null ? "" : value.toString();

                if (isSelected) {
                    c.setBackground(selectionBg);
                    c.setForeground(selectionFg);
                } else if ("Status".equals(colName)) {
                    switch (text.toUpperCase()) {
                        case "CONFIRMED":
                            c.setBackground(confirmedBg);
                            c.setForeground(confirmedFg);
                            break;
                        case "CANCELLED":
                            c.setBackground(cancelledBg);
                            c.setForeground(cancelledFg);
                            break;
                        case "PENDING":
                            c.setBackground(pendingBg);
                            c.setForeground(pendingFg);
                            break;
                        case "REFUNDED":
                            c.setBackground(refundedBg);
                            c.setForeground(refundedFg);
                            break;
                        default:
                            c.setBackground(row % 2 == 0 ? rowColor : rowAltColor);
                            c.setForeground(textColor);
                    }
                } else {
                    c.setBackground(row % 2 == 0 ? rowColor : rowAltColor);
                    c.setForeground(textColor);
                }

                setFont(new Font("Segoe UI", Font.PLAIN, 13));
                setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                return c;
            }
        };

        DefaultTableCellRenderer firstColumnRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {

                Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                if (isSelected) {
                    c.setBackground(selectionBg);
                    c.setForeground(selectionFg);
                } else {
                    c.setBackground(row % 2 == 0 ? firstColBg : firstColAltBg);
                    c.setForeground(textColor);
                }

                setFont(new Font("Segoe UI", Font.PLAIN, 13));
                setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                return c;
            }
        };

        table.getColumnModel().getColumn(0).setCellRenderer(firstColumnRenderer);

        for (int i = 1; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
        
        // Removed custom listener that blocked column 0 selection so the entire row highlights properly
    }

    // ================= SCROLLPANE STYLE =================
    private void styleScrollPane(JScrollPane scrollPane) {

        scrollPane.setBorder(BorderFactory.createLineBorder(panelBorder, 1));
        scrollPane.getViewport().setBackground(panelBg);
        scrollPane.setBackground(pageBg);

        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JScrollBar vertical = scrollPane.getVerticalScrollBar();
        vertical.setUI(new ModernScrollBarUI());
        vertical.setPreferredSize(new Dimension(12, Integer.MAX_VALUE));
        vertical.setUnitIncrement(16);

        JScrollBar horizontal = scrollPane.getHorizontalScrollBar();
        horizontal.setUI(new ModernScrollBarUI());
        horizontal.setPreferredSize(new Dimension(Integer.MAX_VALUE, 12));
        horizontal.setUnitIncrement(16);
    }

    // ================= MODERN SCROLLBAR =================
    static class ModernScrollBarUI extends BasicScrollBarUI {

        private final Color thumbColor = new Color(71, 85, 105);
        private final Color thumbHover = new Color(100, 116, 139);
        private final Color trackColor = new Color(27, 37, 59);

        private boolean hover = false;

        @Override
        protected JButton createDecreaseButton(int orientation) {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle bounds) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(trackColor);
            g2.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
            g2.dispose();
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle bounds) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(hover ? thumbHover : thumbColor);

            g2.fillRoundRect(
                    bounds.x + 2,
                    bounds.y + 2,
                    bounds.width - 4,
                    bounds.height - 4,
                    10,
                    10
            );

            g2.dispose();
        }

        @Override
        protected void installListeners() {
            super.installListeners();

            scrollbar.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    scrollbar.repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    scrollbar.repaint();
                }
            });
        }
    }

    // ================= REFRESH =================
    public void refresh() {
        tableModel.setRowCount(0);

        List<Reservation> list = service.getReservationsForUser(currentUser.getUsername());

        for (Reservation r : list) {
            tableModel.addRow(new Object[]{
                    r.getReservationId(),
                    r.getRoomNumber(),
                    r.getCheckIn(),
                    r.getCheckOut(),
                    r.getNights(),
                    r.getTotalAmount(),
                    r.getStatus(),
                    r.isPaid() ? "Yes" : "No"
            });
        }

        if (list.isEmpty()) {
            tableModel.addRow(new Object[]{
                    "No reservations found.", "", "", "", "", "", "", ""
            });
        }
    }
}