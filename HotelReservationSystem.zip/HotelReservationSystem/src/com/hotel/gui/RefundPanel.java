package com.hotel.gui;

import com.hotel.model.Customer;
import com.hotel.model.Reservation;
import com.hotel.service.HotelService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class RefundPanel extends JPanel {

    private final HotelService service;
    private final Customer currentUser;
    private final Runnable onBack; // NEW: callback invoked when Back button is clicked

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel statusLabel;

    // ---------- Dark Navy Dashboard Palette ----------
    private final Color pageBg       = new Color(15, 23, 42);    // Slate-900 (overall background)
    private final Color panelBg      = new Color(21, 30, 50);    // Card / header panel background
    private final Color panelBorder  = new Color(40, 51, 78);    // Subtle card border
    private final Color rowBg1       = new Color(21, 30, 50);    // Table row (even)
    private final Color rowBg2       = new Color(27, 37, 59);    // Table row (odd)
    private final Color gridColor    = new Color(40, 51, 78);
    private final Color headerBg     = new Color(21, 30, 50);
    private final Color headerText   = new Color(148, 163, 184); // Slate-400 column labels
    private final Color textPrimary  = new Color(226, 232, 240); // Slate-200 body text
    private final Color textMuted    = new Color(148, 163, 184); // Slate-400 subtitle text

    private final Color accent       = new Color(16, 185, 129);  // Emerald accent (refund theme)
    private final Color accentHover  = new Color(5, 150, 105);
    private final Color danger       = new Color(239, 68, 68);
    private final Color neutralBtn   = new Color(30, 41, 59);
    private final Color neutralHover = new Color(51, 65, 85);
    private final Color selectionBg  = new Color(16, 185, 129);

    // Badge colors: [background, text]
    private final Color badgeCancelledBg  = new Color(76, 29, 33);
    private final Color badgeCancelledFg  = new Color(252, 165, 165);
    private final Color badgeRefundedBg   = new Color(49, 39, 96);
    private final Color badgeRefundedFg   = new Color(196, 181, 253);
    private final Color badgeConfirmedBg  = new Color(6, 78, 59);
    private final Color badgeConfirmedFg  = new Color(110, 231, 183);
    private final Color badgePendingBg    = new Color(76, 58, 15);
    private final Color badgePendingFg    = new Color(252, 211, 77);

    // Backward-compatible constructor (no back button shown)
    public RefundPanel(HotelService service, Customer currentUser) {
        this(service, currentUser, null);
    }

    // NEW: constructor with a back-navigation callback
    public RefundPanel(HotelService service, Customer currentUser, Runnable onBack) {
        this.service = service;
        this.currentUser = currentUser;
        this.onBack = onBack;

        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(pageBg);

        add(buildHeaderBar(), BorderLayout.NORTH);

        String[] columns = {"Reservation ID", "Room No.", "Check-in", "Check-out", "Nights", "Total (Rs.)", "Status", "Paid"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(tableModel);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(panelBorder, 1));
        scrollPane.getViewport().setBackground(panelBg);
        scrollPane.setBackground(pageBg);
        add(scrollPane, BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);

        refresh();
    }

    private JPanel buildHeaderBar() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(panelBg);
        wrapper.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(panelBorder, 1),
                new EmptyBorder(18, 20, 18, 20)
        ));

        // Left accent stripe
        JPanel accentStripe = new JPanel();
        accentStripe.setBackground(accent);
        accentStripe.setPreferredSize(new Dimension(4, 10));

        JPanel textCol = new JPanel();
        textCol.setOpaque(false);
        textCol.setLayout(new BoxLayout(textCol, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Process Refund");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Select a reservation and click 'Process 50% Refund' to proceed.");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(textMuted);
        subtitle.setBorder(new EmptyBorder(4, 0, 0, 0));

        textCol.add(title);
        textCol.add(subtitle);

        JPanel left = new JPanel(new BorderLayout(14, 0));
        left.setOpaque(false);

        // Back button — always shown. If no callback was supplied, falls back
        // to closing/hiding the nearest window so it still does something sensible.
        JButton backBtn = buildButton("\u2190 Back", neutralBtn, neutralHover, textPrimary);
        backBtn.addActionListener(e -> {
            if (onBack != null) {
                onBack.run();
            } else {
                Window w = SwingUtilities.getWindowAncestor(this);
                if (w != null) {
                    w.setVisible(false);
                    w.dispose();
                }
            }
        });

        JPanel backAndStripe = new JPanel(new BorderLayout(14, 0));
        backAndStripe.setOpaque(false);
        backAndStripe.add(backBtn, BorderLayout.WEST);
        backAndStripe.add(accentStripe, BorderLayout.EAST);

        left.add(backAndStripe, BorderLayout.WEST);
        left.add(textCol, BorderLayout.CENTER);

        wrapper.add(left, BorderLayout.WEST);
        wrapper.add(buildRefundIcon(), BorderLayout.EAST);

        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        outer.add(wrapper, BorderLayout.CENTER);
        outer.setBorder(new EmptyBorder(0, 0, 15, 0));
        return outer;
    }

    private JComponent buildRefundIcon() {
        JComponent icon = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 40));
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setStroke(new BasicStroke(2.2f));
                g2.setColor(accent);
                int pad = 10;
                // Draw a simple "refund/undo" arrow arc
                g2.drawArc(pad, pad, getWidth() - 2 * pad, getHeight() - 2 * pad, 40, 260);
                g2.dispose();
            }
        };
        icon.setPreferredSize(new Dimension(38, 38));
        icon.setOpaque(false);
        return icon;
    }

    private JPanel buildBottomBar() {
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(pageBg);
        bottom.setBorder(new EmptyBorder(15, 0, 0, 0));

        statusLabel = new JLabel(" Select a booking to process refund.");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        statusLabel.setForeground(textMuted);
        bottom.add(statusLabel, BorderLayout.WEST);

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        buttonRow.setOpaque(false);

        JButton refreshBtn = buildButton("\u27F3 Refresh", neutralBtn, neutralHover, textPrimary);
        refreshBtn.addActionListener(e -> refresh());

        JButton refundBtn = buildButton("\u21BA Process 50% Refund", accent, accentHover, Color.WHITE);
        refundBtn.addActionListener(e -> processRefund());

        buttonRow.add(refreshBtn);
        buttonRow.add(refundBtn);
        bottom.add(buttonRow, BorderLayout.EAST);

        return bottom;
    }

    private void processRefund() {
        int row = table.getSelectedRow();
        if (row < 0) {
            statusLabel.setText(" Please select a reservation first.");
            statusLabel.setForeground(danger);
            return;
        }

        String reservationId = String.valueOf(tableModel.getValueAt(row, 0));
        String status = String.valueOf(tableModel.getValueAt(row, 6));

        if ("CANCELLED".equalsIgnoreCase(status) || "REFUNDED".equalsIgnoreCase(status)) {
            statusLabel.setText(" Reservation is already " + status.toLowerCase() + ".");
            statusLabel.setForeground(textMuted);
            return;
        }

        double totalAmount = Double.parseDouble(String.valueOf(tableModel.getValueAt(row, 5)));
        double refundAmount = totalAmount * 0.5;
        double retainedFee = totalAmount - refundAmount;

        // --- DARK THEMED CONFIRMATION DIALOG ---
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Refund Confirmation", true);
        dialog.setSize(420, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        dialog.getContentPane().setBackground(panelBg);

        JPanel content = new JPanel(new GridLayout(5, 1, 10, 10));
        content.setBackground(panelBg);
        content.setBorder(new EmptyBorder(25, 30, 20, 30));

        JLabel title = new JLabel("Confirm 50% Refund", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        content.add(title);

        content.add(createDetailLabel("Total Originally Paid:", "Rs. " + totalAmount, textPrimary));
        content.add(createDetailLabel("50% Refund to Customer:", "Rs. " + refundAmount, accent));
        content.add(createDetailLabel("50% Cancellation Fee:", "Rs. " + retainedFee, danger));

        JLabel warning = new JLabel("This action cannot be undone.", SwingConstants.CENTER);
        warning.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        warning.setForeground(textMuted);
        content.add(warning);

        dialog.add(content, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        btnPanel.setBackground(rowBg2);

        JButton btnConfirm = buildButton("Confirm Refund", accent, accentHover, Color.WHITE);
        JButton btnCancel = buildButton("Cancel", neutralBtn, neutralHover, textPrimary);

        btnCancel.addActionListener(e -> dialog.dispose());
        btnConfirm.addActionListener(e -> {
            dialog.dispose();
            try {
                boolean successResult = service.refundReservation(reservationId);
                if (successResult) {
                    refresh();
                    statusLabel.setText(" Successfully refunded Rs. " + refundAmount + " for " + reservationId);
                    statusLabel.setForeground(accent);
                }
            } catch (Exception ex) {
                statusLabel.setText(" Error: " + ex.getMessage());
                statusLabel.setForeground(danger);
            }
        });

        btnPanel.add(btnCancel);
        btnPanel.add(btnConfirm);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private JPanel createDetailLabel(String title, String value, Color valueColor) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        JLabel l1 = new JLabel(title);
        l1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l1.setForeground(textMuted);
        JLabel l2 = new JLabel(value);
        l2.setFont(new Font("Segoe UI", Font.BOLD, 16));
        l2.setForeground(valueColor);
        p.add(l1, BorderLayout.WEST);
        p.add(l2, BorderLayout.EAST);
        return p;
    }

    private JButton buildButton(String text, Color bg, Color hover, Color fg) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(38);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setForeground(textPrimary);
        table.setBackground(panelBg);
        table.setGridColor(gridColor);
        table.setShowGrid(true);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setSelectionBackground(new Color(selectionBg.getRed(), selectionBg.getGreen(), selectionBg.getBlue(), 60));
        table.setSelectionForeground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(0, 42));
        header.setBackground(headerBg);
        header.setForeground(headerText);
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, panelBorder));

        // NOTE: header.setBackground() alone is ignored by many Look & Feels
        // (the default header cell renderer paints its own color). We must
        // set an explicit renderer so every header cell is forced dark.
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected,
                                                             boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        tbl, value, isSelected, hasFocus, row, column);
                label.setOpaque(true);
                label.setBackground(headerBg);
                label.setForeground(headerText);
                label.setFont(new Font("Segoe UI", Font.BOLD, 13));
                label.setHorizontalAlignment(SwingConstants.LEFT);
                label.setBorder(new EmptyBorder(0, 14, 0, 14));
                return label;
            }
        });

        DefaultTableCellRenderer plainRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected,
                                                             boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
                setBorder(new EmptyBorder(0, 14, 0, 14));
                setHorizontalAlignment(SwingConstants.LEFT);
                Color base = row % 2 == 0 ? rowBg1 : rowBg2;
                if (isSelected) {
                    c.setBackground(blend(base, selectionBg, 0.25f));
                } else {
                    c.setBackground(base);
                }
                setForeground(textPrimary);
                return c;
            }
        };

        BadgeRenderer badgeRenderer = new BadgeRenderer();

        for (int i = 0; i < table.getColumnCount(); i++) {
            if (i == 6) { // Status column -> pill badge
                table.getColumnModel().getColumn(i).setCellRenderer(badgeRenderer);
            } else {
                table.getColumnModel().getColumn(i).setCellRenderer(plainRenderer);
            }
        }
    }

    private static Color blend(Color a, Color b, float ratio) {
        int r = (int) (a.getRed() * (1 - ratio) + b.getRed() * ratio);
        int g = (int) (a.getGreen() * (1 - ratio) + b.getGreen() * ratio);
        int bl = (int) (a.getBlue() * (1 - ratio) + b.getBlue() * ratio);
        return new Color(r, g, bl);
    }

    /** Renders the Status column as a rounded, color-coded pill badge. */
    private class BadgeRenderer extends JLabel implements javax.swing.table.TableCellRenderer {
        private Color pillBg = badgePendingBg;
        private Color pillFg = badgePendingFg;
        private Color rowBase = rowBg1;

        BadgeRenderer() {
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.BOLD, 12));
            setHorizontalAlignment(SwingConstants.CENTER);
        }

        @Override
        public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected,
                                                         boolean hasFocus, int row, int column) {
            String text = value == null ? "" : value.toString().toUpperCase();
            setText(text);
            rowBase = row % 2 == 0 ? rowBg1 : rowBg2;

            switch (text) {
                case "CANCELLED":
                    pillBg = badgeCancelledBg; pillFg = badgeCancelledFg; break;
                case "REFUNDED":
                    pillBg = badgeRefundedBg; pillFg = badgeRefundedFg; break;
                case "CONFIRMED":
                    pillBg = badgeConfirmedBg; pillFg = badgeConfirmedFg; break;
                default:
                    pillBg = badgePendingBg; pillFg = badgePendingFg; break;
            }
            setForeground(pillFg);
            setBorder(new EmptyBorder(6, 14, 6, 14));
            return this;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(rowBase);
            g2.fillRect(0, 0, getWidth(), getHeight());

            FontMetrics fm = g2.getFontMetrics(getFont());
            int textW = fm.stringWidth(getText());
            int pillW = textW + 28;
            int pillH = 24;
            int x = (getWidth() - pillW) / 2;
            int y = (getHeight() - pillH) / 2;

            g2.setColor(pillBg);
            g2.fillRoundRect(x, y, pillW, pillH, pillH, pillH);
            g2.dispose();

            super.paintComponent(g);
        }
    }

    public void refresh() {
        tableModel.setRowCount(0);
        List<Reservation> list = service.getReservationsForUser(currentUser.getUsername());
        for (Reservation r : list) {
            tableModel.addRow(new Object[]{
                    r.getReservationId(), r.getRoomNumber(), r.getCheckIn(), r.getCheckOut(),
                    r.getNights(), r.getTotalAmount(), r.getStatus(), r.isPaid() ? "Yes" : "No"
            });
        }
    }
}