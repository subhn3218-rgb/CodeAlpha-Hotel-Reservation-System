package com.hotel.gui;

import com.hotel.model.Customer;
import com.hotel.model.Reservation;
import com.hotel.service.HotelService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class CancellationPanel extends JPanel {

    private final HotelService service;
    private final Customer currentUser;
    private final Runnable onBack; // NEW: callback invoked when Back button is clicked

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel statusLabel;

    // ==================== DARK PREMIUM PALETTE ====================
    private final Color bgTop        = new Color(15, 23, 42);
    private final Color bgBottom     = new Color(23, 37, 60);

    private final Color headerBg     = new Color(20, 30, 55);
    private final Color headerText   = new Color(148, 163, 184);
    private final Color headerBorder = new Color(51, 65, 85);

    private final Color rowEven      = new Color(23, 37, 60);
    private final Color rowOdd       = new Color(28, 44, 70);
    private final Color rowHover     = new Color(37, 55, 90);
    private final Color gridColor    = new Color(40, 55, 80);

    private final Color firstColEven = new Color(18, 30, 52);
    private final Color firstColOdd  = new Color(22, 35, 58);

    private final Color textPrimary  = new Color(226, 232, 240);
    private final Color textMuted    = new Color(148, 163, 184);

    private final Color selectionBg  = new Color(220, 38, 38);
    private final Color selectionFg  = Color.WHITE;

    // Status badge colors
    private final Color confirmedBg  = new Color(6,  78,  59,  120);
    private final Color confirmedFg  = new Color(52, 211, 153);
    private final Color cancelledBg  = new Color(127, 29, 29, 120);
    private final Color cancelledFg  = new Color(252, 165, 165);
    private final Color pendingBg    = new Color(120, 53,  15, 120);
    private final Color pendingFg    = new Color(253, 186, 116);
    private final Color refundedBg   = new Color(49,  46, 129, 120);
    private final Color refundedFg   = new Color(167, 139, 250);

    private final Color successColor = new Color(52,  211, 153);
    private final Color errorColor   = new Color(252, 165, 165);
    private final Color idleColor    = new Color(148, 163, 184);

    // ==================== CONSTRUCTORS ====================

    // Backward-compatible constructor (Back button falls back to closing the window)
    public CancellationPanel(HotelService service, Customer currentUser) {
        this(service, currentUser, null);
    }

    // NEW: constructor with a back-navigation callback
    public CancellationPanel(HotelService service, Customer currentUser, Runnable onBack) {
        this.service = service;
        this.currentUser = currentUser;
        this.onBack = onBack;

        setLayout(new BorderLayout(0, 0));
        setOpaque(false);

        // Outer padding panel with gradient background
        JPanel wrapper = new JPanel(new BorderLayout(0, 14)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, bgTop, 0, getHeight(), bgBottom);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        wrapper.setOpaque(false);
        wrapper.setBorder(new EmptyBorder(20, 20, 20, 20));

        // ---- Title Header ----
        wrapper.add(buildTitleHeader(), BorderLayout.NORTH);

        // ---- Table Setup ----
        String[] columns = {
                "Reservation ID", "Room No.", "Check-in", "Check-out",
                "Nights", "Total (Rs.)", "Status", "Paid"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };

        table = new JTable(tableModel);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        styleScrollPane(scrollPane);

        wrapper.add(scrollPane, BorderLayout.CENTER);
        wrapper.add(buildBottomBar(), BorderLayout.SOUTH);

        add(wrapper, BorderLayout.CENTER);

        refresh();
    }

    // ==================== TITLE HEADER ====================
    private JPanel buildTitleHeader() {
        JPanel header = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(30, 41, 59));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                // Red left accent bar
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 38, 38),
                        0, getHeight(), new Color(153, 27, 27));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, 5, getHeight(), 6, 6);
                g2.fillRect(3, 0, 3, getHeight());
                // Subtle border
                g2.setColor(new Color(51, 65, 85));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.dispose();
            }
        };
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));
        header.setPreferredSize(new Dimension(0, 64));

        // NEW: Back button (left side, before the texts)
        JButton backBtn = buildGradientButton(
                "\u2190  Back",
                new Color(51, 65, 85),
                new Color(30, 41, 59));
        backBtn.addActionListener(e -> {
            if (onBack != null) {
                onBack.run();
            } else {
                Window w = SwingUtilities.getWindowAncestor(this);
                if (w != null) {
                    w.setVisible(false);
                    w.dispose();
                }
            }
        });

        JLabel title = new JLabel("Cancel Reservation");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(241, 245, 249));

        JLabel sub = new JLabel("Select a reservation and click 'Cancel Booking' to proceed.");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(new Color(148, 163, 184));

        JPanel texts = new JPanel(new GridLayout(2, 1, 0, 2));
        texts.setOpaque(false);
        texts.add(title);
        texts.add(sub);

        JPanel leftGroup = new JPanel(new BorderLayout(16, 0));
        leftGroup.setOpaque(false);
        leftGroup.add(backBtn, BorderLayout.WEST);
        leftGroup.add(texts, BorderLayout.CENTER);

        header.add(leftGroup, BorderLayout.CENTER);

        // Danger icon label
        JLabel icon = new JLabel("🚫", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        icon.setPreferredSize(new Dimension(50, 50));
        header.add(icon, BorderLayout.EAST);

        return header;
    }

    // ==================== BOTTOM BAR ====================
    private JPanel buildBottomBar() {
        JPanel bottom = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(20, 30, 52));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.setColor(new Color(40, 55, 80));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                g2.dispose();
            }
        };
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(12, 16, 12, 16));

        // Status label (left)
        statusLabel = new JLabel("  Select a reservation to cancel.");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        statusLabel.setForeground(idleColor);
        bottom.add(statusLabel, BorderLayout.WEST);

        // Buttons (right)
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        btnRow.setOpaque(false);

        JButton refreshBtn = buildGradientButton(
                "↻  Refresh",
                new Color(51, 65, 85),
                new Color(30, 41, 59));
        refreshBtn.addActionListener(e -> {
            refresh();
            setStatus("Table refreshed.", idleColor);
        });

        JButton cancelBtn = buildGradientButton(
                "✕  Cancel Booking",
                new Color(220, 38, 38),
                new Color(153, 27, 27));
        cancelBtn.addActionListener(e -> processCancellation());

        btnRow.add(refreshBtn);
        btnRow.add(cancelBtn);
        bottom.add(btnRow, BorderLayout.EAST);

        return bottom;
    }

    // ==================== CANCELLATION LOGIC ====================
    private void processCancellation() {
        int row = table.getSelectedRow();

        if (row < 0) {
            setStatus("  ⚠  Please select a reservation first.", errorColor);
            return;
        }

        String reservationId = String.valueOf(tableModel.getValueAt(row, 0));
        String currentStatus = String.valueOf(tableModel.getValueAt(row, 6));

        if ("CANCELLED".equalsIgnoreCase(currentStatus) || "REFUNDED".equalsIgnoreCase(currentStatus)) {
            setStatus("  ⚠  Reservation " + reservationId + " is already " + currentStatus.toLowerCase() + ".", errorColor);
            return;
        }

        // Custom styled confirmation dialog
        int confirm = showStyledConfirm(
                "Cancel Reservation",
                "Are you sure you want to cancel\nReservation ID: " + reservationId + "?\n\nThis action cannot be undone."
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            boolean success = service.Cancelreservation(reservationId);
            if (success) {
                refresh();
                setStatus("  ✔  Reservation " + reservationId + " cancelled successfully.", successColor);
            } else {
                setStatus("  ✕  Failed to cancel reservation " + reservationId + ".", errorColor);
            }
        } catch (Exception ex) {
            setStatus("  ✕  Error: " + ex.getMessage(), errorColor);
        }
    }

    private int showStyledConfirm(String title, String message) {
        return JOptionPane.showConfirmDialog(
                this, message, title,
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
    }

    private void setStatus(String message, Color color) {
        statusLabel.setForeground(color);
        statusLabel.setText(message);
    }

    // ==================== GRADIENT BUTTON ====================
    private JButton buildGradientButton(String label, Color c1, Color c2) {
        JButton btn = new JButton(label) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean hover = Boolean.TRUE.equals(getClientProperty("hover"));
                GradientPaint gp = new GradientPaint(
                        0, 0,      hover ? c1.brighter() : c1,
                        0, getHeight(), hover ? c2.brighter() : c2);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setBorder(new EmptyBorder(10, 22, 10, 22));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.putClientProperty("hover", true);  btn.repaint(); }
            @Override public void mouseExited(MouseEvent e)  { btn.putClientProperty("hover", false); btn.repaint(); }
        });
        return btn;
    }

    // ==================== TABLE STYLING ====================
    private void styleTable(JTable tbl) {
        tbl.setRowHeight(36);
        tbl.setShowGrid(true);
        tbl.setGridColor(gridColor);
        tbl.setIntercellSpacing(new Dimension(0, 1));
        tbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tbl.setBackground(rowEven);
        tbl.setForeground(textPrimary);
        tbl.setSelectionBackground(selectionBg);
        tbl.setSelectionForeground(selectionFg);
        tbl.setFocusable(false);

        // ---- Header ----
        JTableHeader header = tbl.getTableHeader();
        header.setPreferredSize(new Dimension(0, 44));
        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean sel, boolean focus, int row, int col) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, value, false, false, row, col);
                lbl.setOpaque(true);
                lbl.setBackground(headerBg);
                lbl.setForeground(headerText);
                lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
                lbl.setHorizontalAlignment(SwingConstants.LEFT);
                lbl.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 2, 1, headerBorder),
                        BorderFactory.createEmptyBorder(0, 14, 0, 14)));
                return lbl;
            }
        });

        // ---- Data rows renderer ----
        DefaultTableCellRenderer dataRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean isSelected,
                    boolean hasFocus, int row, int col) {

                super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, col);
                String colName = t.getColumnName(col);
                String text    = value == null ? "" : value.toString();

                setFont(new Font("Segoe UI", Font.PLAIN, 13));
                setBorder(new EmptyBorder(0, 14, 0, 14));

                if (isSelected) {
                    setBackground(selectionBg);
                    setForeground(selectionFg);
                } else if ("Status".equals(colName)) {
                    applyStatusStyle(this, text);
                } else {
                    setBackground(row % 2 == 0 ? rowEven : rowOdd);
                    setForeground(textPrimary);
                }
                setOpaque(true);
                return this;
            }
        };

        // ---- First column renderer (locked style) ----
        DefaultTableCellRenderer firstColRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean isSelected,
                    boolean hasFocus, int row, int col) {
                super.getTableCellRendererComponent(t, value, false, false, row, col);
                setBackground(row % 2 == 0 ? firstColEven : firstColOdd);
                setForeground(textMuted);
                setFont(new Font("Segoe UI", Font.PLAIN, 12));
                setBorder(new EmptyBorder(0, 14, 0, 14));
                setOpaque(true);
                return this;
            }
        };

        tbl.getColumnModel().getColumn(0).setCellRenderer(firstColRenderer);
        for (int i = 1; i < tbl.getColumnCount(); i++) {
            tbl.getColumnModel().getColumn(i).setCellRenderer(dataRenderer);
        }

        // Column widths
        int[] widths = {180, 80, 100, 100, 60, 110, 100, 60};
        for (int i = 0; i < widths.length && i < tbl.getColumnCount(); i++) {
            tbl.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        // Hover row effect
        tbl.addMouseMotionListener(new MouseAdapter() {
            int lastRow = -1;
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = tbl.rowAtPoint(e.getPoint());
                if (row != lastRow) {
                    lastRow = row;
                    tbl.repaint();
                }
            }
        });
    }

    private void applyStatusStyle(JLabel lbl, String status) {
        switch (status.toUpperCase()) {
            case "CONFIRMED":
                lbl.setBackground(confirmedBg); lbl.setForeground(confirmedFg); break;
            case "CANCELLED":
                lbl.setBackground(cancelledBg); lbl.setForeground(cancelledFg); break;
            case "PENDING":
                lbl.setBackground(pendingBg);   lbl.setForeground(pendingFg);   break;
            case "REFUNDED":
                lbl.setBackground(refundedBg);  lbl.setForeground(refundedFg);  break;
            default:
                lbl.setBackground(rowEven);     lbl.setForeground(textPrimary); break;
        }
    }

    // ==================== SCROLLPANE STYLING ====================
    private void styleScrollPane(JScrollPane sp) {
        sp.setBorder(BorderFactory.createLineBorder(new Color(40, 55, 80), 1));
        sp.getViewport().setBackground(rowEven);
        sp.setBackground(rowEven);

        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        // Vertical scrollbar
        JScrollBar vsb = sp.getVerticalScrollBar();
        vsb.setPreferredSize(new Dimension(10, Integer.MAX_VALUE));
        vsb.setUnitIncrement(20);
        vsb.setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(99, 102, 241);
                this.trackColor = new Color(20, 30, 52);
            }
            @Override protected JButton createDecreaseButton(int o) {
                JButton b = new JButton(); b.setPreferredSize(new Dimension(0,0)); return b;
            }
            @Override protected JButton createIncreaseButton(int o) {
                JButton b = new JButton(); b.setPreferredSize(new Dimension(0,0)); return b;
            }
            @Override
            protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(trackColor);
                g2.fillRect(r.x, r.y, r.width, r.height);
                g2.dispose();
            }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                if (r.isEmpty()) return;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Purple gradient thumb
                GradientPaint gp = new GradientPaint(
                        r.x, r.y,          new Color(129, 140, 248),
                        r.x, r.y+r.height, new Color(99, 102, 241));
                g2.setPaint(gp);
                g2.fillRoundRect(r.x + 2, r.y + 3, r.width - 4, r.height - 6, 8, 8);
                g2.dispose();
            }
        });

        // Horizontal scrollbar
        JScrollBar hsb = sp.getHorizontalScrollBar();
        hsb.setPreferredSize(new Dimension(Integer.MAX_VALUE, 10));
        hsb.setUnitIncrement(20);
        hsb.setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(99, 102, 241);
                this.trackColor = new Color(20, 30, 52);
            }
            @Override protected JButton createDecreaseButton(int o) {
                JButton b = new JButton(); b.setPreferredSize(new Dimension(0,0)); return b;
            }
            @Override protected JButton createIncreaseButton(int o) {
                JButton b = new JButton(); b.setPreferredSize(new Dimension(0,0)); return b;
            }
            @Override
            protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(trackColor);
                g2.fillRect(r.x, r.y, r.width, r.height);
                g2.dispose();
            }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                if (r.isEmpty()) return;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(
                        r.x, r.y,       new Color(129, 140, 248),
                        r.x+r.width, r.y, new Color(99, 102, 241));
                g2.setPaint(gp);
                g2.fillRoundRect(r.x + 3, r.y + 2, r.width - 6, r.height - 4, 8, 8);
                g2.dispose();
            }
        });
    }

    // ==================== REFRESH ====================
    public void refresh() {
        tableModel.setRowCount(0);
        List<Reservation> list = service.getReservationsForUser(currentUser.getUsername());

        for (Reservation r : list) {
            tableModel.addRow(new Object[]{
                    r.getReservationId(), r.getRoomNumber(),
                    r.getCheckIn(), r.getCheckOut(),
                    r.getNights(), r.getTotalAmount(),
                    r.getStatus(), r.isPaid() ? "Yes" : "No"
            });
        }

        if (list.isEmpty()) {
            tableModel.addRow(new Object[]{
                    "No reservations found.", "", "", "", "", "", "", ""
            });
        }
    }
}